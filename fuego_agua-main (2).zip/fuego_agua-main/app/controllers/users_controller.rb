class UsersController < ApplicationController
  def show
  end
end
