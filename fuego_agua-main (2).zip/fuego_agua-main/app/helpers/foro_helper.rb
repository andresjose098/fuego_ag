module ForoHelper
end
