class PersonalizarVela < ApplicationRecord
end
