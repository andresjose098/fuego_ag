class ForoVelasController < ApplicationController
  def index
  end
end
