class VelaGanadoraEdicionLimitadasController < ApplicationController
  def index
  end
end
