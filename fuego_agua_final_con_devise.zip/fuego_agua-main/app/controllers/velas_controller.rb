class VelasController < ApplicationController
  before_action :authenticate_user!

  def new
    @vela = Vela.new
  end

  def create
    @vela = current_user.velas.build(vela_params)
    if @vela.save
      redirect_to velas_path, notice: "¡Tu vela fue publicada!"
    else
      render :new
    end
  end

  def index
    @velas = current_user.admin? ? Vela.all : current_user.velas
  end

  def destroy
    @vela = current_user.admin? ? Vela.find(params[:id]) : current_user.velas.find(params[:id])
    @vela.destroy
    redirect_to velas_path, notice: 'La vela fue eliminada exitosamente.'
  end

  private

  def vela_params
    params.require(:vela).permit(:modelo, :color, :estilo, :dibujo, :mensaje)
  end
end
